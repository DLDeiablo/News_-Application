// server.js
const API_KEY = "a93bdacc6fed4cc6a9337295a04f84ed";

const url = "https://newsapi.org/v2/everything?q=";
const express = require("express");
const fetch = require("node-fetch");

const app = express();
const PORT = 3000;

const NEWS_API_URL = "https://newsapi.org/v2/everything?q=";

app.get("/news", async (req, res) => {
  const query = req.query.q;
  const url = `https://newsapi.org/v2/everything?q=ipl&apiKey=a93bdacc6fed4cc6a9337295a04f84ed`;

  try {
    const response = await fetch(url);
    const data = await response.json();
    res.json(data);
  } catch (error) {
    console.error("Error fetching news:", error);
    res.status(500).json({ error: "Error fetching news" });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
